// onboarding screen colors
import 'package:flutter/material.dart';

var onBoardingColor01 = Colors.deepOrangeAccent.shade100;
var onBoardingColor02 = Colors.orange.shade200;
var onBoardingColor03 = Colors.pink.shade200;