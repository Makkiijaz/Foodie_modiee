// Onboarding image_strings and Assets

const String onBoardingImage01 = "assets/onboardingimages/onboarding_image_01.png";
const String onBoardingImage02 = "assets/onboardingimages/onboarding_image_02.png";
const String onBoardingImage03 = "assets/onboardingimages/onboarding_image_03.png";