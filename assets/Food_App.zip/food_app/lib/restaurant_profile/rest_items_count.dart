class Items{
  var data = [
    {
      'RestImage': 'assets/rest1.png',
      'Name': 'Ramada Hotel',
      'Description':'best hotel in the town',
      'type':'Restaurant',
      'distance':'2.6 km',
      'hmRatings':'(21 Ratings)',
      'ratings':'4.6',
    },
    {
      'RestImage': 'assets/rest1.png',
      'Name': 'Ramada Hotel',
      'Description':'best hotel in the town',
      'type':'Restaurant',
      'distance':'2.6 km',
      'hmRatings':'(21 Ratings)',
      'ratings':'4.6',

    },
    {
      'RestImage': 'assets/rest1.png',
      'Name': 'Ramada Hotel',
      'Description':'best hotel in the town',
      'type':'Restaurant',
      'distance':'2.6 km',
      'hmRatings':'(21 Ratings)',
      'ratings':'4.6',
    },
    {
      'RestImage': 'assets/rest1.png',
      'Name': 'Ramada Hotel',
      'Description':'best hotel in the town',
      'type':'Restaurant',
      'distance':'2.6 km',
      'hmRatings':'(21 Ratings)',
      'ratings':'4.6',
    },
    {
      'RestImage': 'assets/rest1.png',
      'Name': 'Ramada Hotel',
      'Description':'best hotel in the town',
      'type':'Restaurant',
      'distance':'2.6 km',
      'hmRatings':'(21 Ratings)',
      'ratings':'4.6',
    },
  ];
}